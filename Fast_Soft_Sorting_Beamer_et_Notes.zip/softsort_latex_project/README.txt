Fast Differentiable Sorting and Ranking — Beamer & notes (Novembre 2026)

FICHIERS
presentation.tex -> présentation Beamer, 13 pages (11 pages de contenu + titre + références)
presentation.pdf -> version compilée
notes_detaillees.tex -> notes suivant le même parcours, en français
notes_detaillees.pdf -> version compilée (6 pages)
figures/ -> les quatre figures PNG des expériences du notebook CPU

COMPILATION (depuis ce dossier) :
    pdflatex presentation.tex
    pdflatex presentation.tex
    pdflatex notes_detaillees.tex
    pdflatex notes_detaillees.tex

DÉROULÉ ORAL POUR ~10 MINUTES
- Slide 1 (titre) : 0:10
- Slide 2 (contexte) : 0:50
- Slides 3-5 (géométrie, projection, PAV) : 3:00
- Slide 6 (protocole) : 0:40
- Slides 7-10 (expériences) : 4:20
- Slides 11-12 (discussion et conclusion) : 1:00
- Slide 13 : référence en réserve (non présentée à l'oral)
TOTAL : 10:00

Les résultats numériques des slides et notes sont ceux de l'exécution CPU précédente.
Ils sont spécifiques à cette exécution ; réévaluer si le notebook est relancé.
La présentation décrit une reproduction pédagogique et une extension, pas une validation
indépendante exhaustive des expériences originales.
